package org.anudip.hibernatePropertiesApplication.application;

import org.anudip.hibernatePropertiesApplication.bean.Country;
import org.anudip.hibernatePropertiesApplicationdao.DatabaseHandler;
import org.hibernate.Session;
import org.hibernate.Transaction;
import java.util.Scanner;



public class CountryInsertUseDatabaseHandler {

	public static void main(String[] args) throws Exception {
		Scanner scanner = new Scanner(System.in); 
		System.out.println("Enter country code:");
		int code = Integer.parseInt(scanner.nextLine());
		System.out.println("Enter country name:");
		String name = scanner.nextLine();
		System.out.println("Enter capital name:");
		String capital = scanner.nextLine();
		System.out.println("Enter GDP:");
		double gdp = Double.parseDouble(scanner.nextLine());
		Country country = new Country(code, name, capital, gdp);
		DatabaseHandler dbHandler=DatabaseHandler.getDatabaseHandler();
		//A Session is used to get a physical connection with a database for specific period of time. It is a lightweight object.
   	    Session session=dbHandler.createSession();
   	// Create transaction object for data insertion
		   	 Transaction transaction=session.beginTransaction();
		   //save the record in database
		   	 session.persist(country);
		   	 //commit the saving
		   	 transaction.commit();
		   	 session.close();
		   	 System.out.println("New Record Added");	
		

	}

}
