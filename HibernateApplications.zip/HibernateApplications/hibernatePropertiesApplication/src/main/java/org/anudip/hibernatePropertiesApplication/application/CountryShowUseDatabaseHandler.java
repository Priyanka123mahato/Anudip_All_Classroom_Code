package org.anudip.hibernatePropertiesApplication.application;

import java.util.List;
import org.anudip.hibernatePropertiesApplication.bean.Country;
import org.anudip.hibernatePropertiesApplicationdao.DatabaseHandler;
import org.hibernate.Session;
import org.hibernate.query.Query;


public class CountryShowUseDatabaseHandler {

	public static void main(String[] args)throws Exception {
		DatabaseHandler dbHandler=DatabaseHandler.getDatabaseHandler();
   	    Session session=dbHandler.createSession();
   	 String queryStatement="from Country";
   	Query<Country> query=session.createQuery(queryStatement);
    List<Country> countryList=query.list();
    countryList.forEach(country->System.out.println(country));
	   	 session.close();

		

	}

}
