package org.anudip.hibernatePropertiesApplication.application;
import java.util.List;
import java.util.Properties;

import org.anudip.hibernatePropertiesApplication.bean.Country;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;


public class CountryShow {

	public static void main(String[] args) throws Exception {
		// Properties class stores data in key/values pair so we declare an object of Properties class
				Properties property=new Properties();
				// object of Properties class load hibernate.properties file and store it's contents in key/value pair
				property.load(Thread.currentThread().getContextClassLoader().getResourceAsStream("hibernate.properties"));
				
		// Configuration object is instantiated
		Configuration config = new Configuration();
		
		config.setProperties(property);
		//mention the object Relation Mapper class
		config.addAnnotatedClass(Country.class);
		
	 // create session factory object based on the hibernate.cfg.xml file
	      SessionFactory factory=config.buildSessionFactory();
	   // SessionFactory object creates the session object
	   	    Session session=factory.openSession();
	   	 String queryStatement="from Country";
	   	Query<Country> query=session.createQuery(queryStatement);
	    List<Country> countryList=query.list();
	    countryList.forEach(country->System.out.println(country));
		   	 session.close();
	}
}
		

	


