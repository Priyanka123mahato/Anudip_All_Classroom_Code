package org.anudip.oneToManyBidirectional.application;

import java.util.List;
import org.anudip.oneToManyBidirectional.bean.Suppliers;
import org.anudip.oneToManyBidirectional.dao.DatabaseHandler;
import org.hibernate.Session;
import org.hibernate.query.Query;

public class SupplierShow {

	public static void main(String[] args) throws Exception{
		DatabaseHandler dbHandler=DatabaseHandler.getDatabaseHandler();
   	    Session session=dbHandler.createSession();
   	 String queryStatement="from Suppliers";
   	Query<Suppliers> query=session.createQuery(queryStatement);
    List<Suppliers> supplierList=query.list();
    supplierList.forEach(supplier->System.out.println(supplier));
	   	 session.close();
	}

}
