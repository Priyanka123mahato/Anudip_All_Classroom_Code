package org.anudip.labAss.shop;

public class GradeMismatchException extends RuntimeException{
    static final long serialVersionUID=1L;
    public GradeMismatchException(String message) {
    	super(message);
    }
}
