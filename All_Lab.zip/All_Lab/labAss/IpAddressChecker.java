package org.anudip.labAss;

import java.util.Scanner;

public class IpAddressChecker {
	//Member function(verifying IP address is valid or not)
	 public static boolean isValidIPAddress(String ipAddress) {
		 String ipFormat= "^((25[0-5]|2[0-4][0-9]|[0-1]?[0-9][0-9]?)\\.){3}(25[0-5]|2[0-4][0-9]|[0-1]?[0-9][0-9]?)$";
		 return ipAddress.matches(ipFormat);
	}
	 
     public static void main(String[] args) {
		//Accepting input from the user
		Scanner scanner = new Scanner(System.in);
	    System.out.print("Enter the IP address: ");
	    String ipAddress = scanner.nextLine();
	    
	  //display accepted IP address is valid or not
	    if (isValidIPAddress(ipAddress)) {
	        System.out.println("Valid");
	    } else {
	        System.out.println("Invalid");
	    }
	    scanner.close();
		}//end of main method
     
	}//end of class


	

