package org.anudip.labAss;

import java.util.Arrays;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PancardChecker {
	//Member function(Check pan card consists of alpha-numerical figure or not and length is always be 10
	public static boolean isValidPanCard(String pancardNumber) {
		Pattern p1 = Pattern.compile("[a-zA-Z0-9]{10}$");
		Matcher m1 =p1.matcher(pancardNumber);
		System.out.println(m1.matches());
		return m1.matches();
		
	}
	// Member function(Arranged Pan card in required format)
	public static String arangedPancardNumber( String pancardNumber) {
		pancardNumber=pancardNumber.toUpperCase();
		String numbers="";
		String alphabets="";
		//Store numbers and alphabets into separate String
		for(int i=0; i<pancardNumber.length();i++) {
			char c=pancardNumber.charAt(i);
			if('0'<=c && c<='9') {
				numbers=numbers+c;
			}else {
				alphabets=alphabets+c;
			}
		}
		//String have to contain same numbers of "Numbers & Alphabets"
		if(numbers.length()==0|| alphabets.length()==0 ||numbers.length()!=5 || alphabets.length()!=5) {
			return "Invalid";
		}
		//Sort numbers and alphabets
		char[]numberArr=numbers.toCharArray();
		Arrays.sort(numberArr);
		String sortedNumbers=new String(numberArr);
		char[]alphaArr=alphabets.toCharArray();
		Arrays.sort(alphaArr);
		
		//reverse the sorted alphabets
		StringBuffer reversedAlphabets=new StringBuffer(new String(alphaArr));
		reversedAlphabets.reverse();
		//return the final required format
		return sortedNumbers+reversedAlphabets;
		}

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		//Accepting pan card number
		System.out.println("Enter the pancard number: ");
		String pancardNumber =scanner.nextLine();
		// check valid pan card or not and display
		if(isValidPanCard(pancardNumber)) {
			String arangedPancardNumber=arangedPancardNumber(pancardNumber);
			System.out.println(arangedPancardNumber);
		}else {
		System.out.println("Invalid");
		}
	scanner.close();
	}//end of main
}
