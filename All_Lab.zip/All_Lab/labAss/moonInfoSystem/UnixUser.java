package org.anudip.labAss.moonInfoSystem;

public class UnixUser {
	//Member data
	private Integer userId;
	private Integer employeeId;
	private String username;
	private String userType;
	private static int idGenSuper=1012;
	private static int idGenOrdinary=1000;
	public UnixUser() {
		super();
		// TODO Auto-generated constructor stub
	}
	//Constructor with fields
	public UnixUser(Integer employeeId, String username, String userType) {
		super();
		this.userId=UnixUser.generateId(userType);
		this.employeeId = employeeId;
		this.username = username;
		this.userType = userType;
		
		
	}
	
	//getters and setters method of the fields
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public Integer getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getUserType() {
		return userType;
	}
	public void setUserType(String userType) {
		this.userType = userType;
	}
	@Override
	public String toString() {
		String output=String.format("%-10s %-10s %-20s %-10s",userId,employeeId,username,userType);
		return output;
	}
	@Override
	public int hashCode() {
		return this.employeeId;
	}
	//employeeId is unique
	@Override
	public boolean equals(Object obj) {
		UnixUser other = (UnixUser) obj;
		if(this.hashCode()==other.hashCode()) {
			return true;
		}else {
			return false;
		}
	}
	 //function to generate id
	private static int generateId(String userType) {
		int idGenerator;
		if(userType.equals("Super")) {
			idGenerator=++idGenSuper;
		}else {
			idGenerator=++idGenOrdinary;
		}
		return idGenerator;
	}
	

}
