package org.anudip.labAss.moonInfoSystem;


import java.util.LinkedHashSet;
import java.util.Scanner;

public class UnixUserMain {
	public static boolean checkPrime(int no) {
        if (no <= 1) {
            return false;
        }
        for (int i = 2; i <= Math.sqrt(no); i++) {
            if (no % i == 0) {
                return false;
            }
        }
        return true;
    }


	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		//accept the number of unix-user
		System.out.println("Enter number of users id to create: ");
		int number=Integer.parseInt(scanner.nextLine());
		
		
		LinkedHashSet<UnixUser>userSet = new LinkedHashSet<UnixUser>();
		
		//accept all users details
		System.out.println("Enter all users details one line at a time");
		for(int i=0;i<number;i++) {
			String stg = scanner.nextLine();
			String []arr=stg.split(",");
			int empId =Integer.parseInt(arr[0]);
			UnixUser unixuser = new UnixUser(empId,arr[1],arr[2]);
			userSet.add(unixuser);
		}//end of loop
		
		System.out.println(String.format("%-10s %-10s %-20s %-10s","userId","employeeId","username","userType"));
		userSet.forEach(str->System.out.println(str));
		
		scanner.close();
	}

}
