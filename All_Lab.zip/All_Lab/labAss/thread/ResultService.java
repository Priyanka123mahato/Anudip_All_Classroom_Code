package org.anudip.labAss.thread;

public class ResultService {
	public static String gradeCalculation(StudentResult result) {
		double percentage =((result.getHalfYearlyTotal()+result.getAnnualTotal())/1000)*100;
		String str;
       if(percentage>=90) {
    	   str= "E";
       }else if(percentage>=75) {
    	   str= "V";
       }else if(percentage>=60) {
    	   str= "G";
       }else if(percentage>=45) {
    	   str= "P";
       }else {
    	  str= "F";
       }
       return str;
	}


}
