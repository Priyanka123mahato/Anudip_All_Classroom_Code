package org.anudip.labAss.user;

public class User {
	//Member Data
	private String userId;
	private String password;
	
	//getters and setters method
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}


}//end of class
