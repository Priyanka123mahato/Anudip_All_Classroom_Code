package org.anudip.labAss;
import java.util.Arrays;
import java.util.Scanner;

public class Anagram {
	
	//function to check two strings are anagram or not
	public static boolean checkAnagram(char[]str1, char[]str2) {
		//length of two String
		int length1=str1.length;
		int length2=str2.length;
		//check if the length of two strings are same or not
		if(length1!=length2) {
			return false;
		}
		//sort both string
		Arrays.sort(str1);
		Arrays.sort(str2);

		//compare the Strings
		for(int i=0; i<length1; i++) {
			if(str1[i]!=str2[i]) {
				return false;
			}
		}
		return true;
	}
	
    //Main Method
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		//accept  String1
		System.out.println("Enter the first String: ");
		String string1 = scanner.nextLine();
		//accept String2
		System.out.println("Enter the second String: ");
		String string2 = scanner.nextLine();
		
		//replace white space and covert it into lower case
		String newString1=string1.replaceAll(" ","").toLowerCase();
		String newString2=string2.replaceAll(" ","").toLowerCase();
		
		//convert string to array
		char []str1 =newString1.toCharArray();
		char []str2 =newString2.toCharArray();
		
		//check two strings are anagram or not
		if(checkAnagram(str1,str2)) {
			System.out.println("Two strings are anagram of each other");
		}else {
			System.out.println("Two strings are not anagram of each other");
		}
		
		scanner.close();
	}

}
