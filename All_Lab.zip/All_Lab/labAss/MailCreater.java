package org.anudip.labAss;
import java.util.Scanner;
public class MailCreater {
	//member function
	public static String createMailAccount(String studentName) {
		//converting to lowercase
		studentName=studentName.toLowerCase();		
		String []arr =studentName.split(" ");
		int length = arr.length;
		String mailId="";
		
		for(int i=0; i<length; i++) {
			if(i==length-1) {
				mailId=mailId+arr[i];
				break;
			}
			mailId=mailId+arr[i]+".";
		}
		return mailId+"@tsr.edu";
 }
     
	public static void main(String[] args) {
		Scanner scanner =new Scanner(System.in);
		//Accept Student Name
		System.out.println("Enter the name of the student: ");
		String studentName =scanner.nextLine();

		//creates student mail id
		String studentMailId =createMailAccount(studentName);
		
		//Display student mail id
		System.out.println("The Mail Id of the student is: "+studentMailId);
		
		scanner.close();
	}

}

