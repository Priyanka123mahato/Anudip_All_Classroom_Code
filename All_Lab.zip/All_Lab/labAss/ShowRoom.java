package org.anudip.labAss;

import java.util.Scanner;

public class ShowRoom{
	//Member data
     private String name;
     private long mobno;
     private double cost;
     private double dis;
     private double amount;
     //initialize the data members
     public ShowRoom(){
          name = "";
          mobno = 0;
          cost = 0.0;
          dis = 0.0;
          amount = 0.0;
     }
     //Member method for accepting input 
     public void input() {
          Scanner scanner = new Scanner(System.in);
          System.out.print("Enter customer name: ");
          name = scanner.nextLine();
          System.out.print("Enter customer mobile no: ");
          mobno = scanner.nextLong();
          System.out.print("Enter cost: ");
          cost = scanner.nextDouble();
          scanner.close();
      }
      //Member method for calculating discount and amount based on cost
      public void calculate() {
             int discountPercent = 0;
             if (cost <= 10000) {
            	 discountPercent = 5;
             }
             else if (cost <= 20000) {
            	 discountPercent = 10;
             }
             else if (cost <= 35000) {
            	 discountPercent = 15;
             }
             else {
            	 discountPercent = 20;
             }
             //calculate discount and amount
             dis = cost * discountPercent / 100.0;
             amount = cost - dis;
      }
      //Member method for Display customer name,mobile number and amount
       public void display() {
            System.out.println("Customer Name: " + name);
            System.out.println("Mobile Number: " + mobno);
            System.out.println("Amout after discount: " + amount);
      }

      public static void main(String args[]) {
        //Object Creation and ShowRoom() constructor called 
        ShowRoom object = new ShowRoom();
        //Call the member methods
        object.input();
        object.calculate();
        object.display();
     }//end of main

}