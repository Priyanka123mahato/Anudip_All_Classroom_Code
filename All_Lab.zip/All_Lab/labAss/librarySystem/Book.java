package org.anudip.labAss.librarySystem;

import java.util.Comparator;


public class Book {
	//Member data
	Integer bookNumber;
	String bookTitle;
	String author;
	//Non-parameterized constructor
	public Book() {
		super();
	}
	//Parameterized constructor
	public Book(Integer bookNumber, String bookTitle, String author) {
		super();
		this.bookNumber = bookNumber;
		this.bookTitle = bookTitle;
		this.author = author;
	}
	public Integer getBookNumber() {
		return bookNumber;
	}
	public void setBookNumber(Integer bookNumber) {
		this.bookNumber = bookNumber;
	}
	public String getBookTitle() {
		return bookTitle;
	}
	public void setBookTitle(String bookTitle) {
		this.bookTitle = bookTitle;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	@Override
	public String toString() {
		 String output=String.format("%-10s %-35s %-20s",bookNumber,bookTitle,author);
	     return  output;
	}
	
	}//end of Book class

	//compare bookNumbers of two book objects
	class NumberComparator implements Comparator<Book>{
		public int compare(Book first,Book second) {
			Integer firstNumber=first.getBookNumber();
			Integer secondNumber =second.getBookNumber();
			return firstNumber.compareTo(secondNumber);
			}
	}
	//compare bookTitles of two book objects
	class TitleComparator implements Comparator<Book>{
		public int compare(Book first,Book second) {
			String firstTitle=first.getBookTitle();
			String secondTitle =second.getBookTitle();
			return firstTitle.compareTo(secondTitle);
			}
	}
	//compare author's names of two book objects
		class AuthorComparator implements Comparator<Book>{
		public int compare(Book first,Book second) {
			String firstAuthor=first.getAuthor();
			String secondAuthor =second.getAuthor();
			return firstAuthor.compareTo(secondAuthor);
		  }
	}//end of class
	



