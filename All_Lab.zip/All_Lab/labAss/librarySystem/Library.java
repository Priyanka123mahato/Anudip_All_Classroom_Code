package org.anudip.labAss.librarySystem;

import java.util.ArrayList;
import java.util.List;


public class Library {
private static ArrayList<Book> bookList = new ArrayList<>();
	 
	//static block to store at least 6 books object into the list
	static {
		bookList.add(new Book(202,"Dui Bon","Satyajit Ray"));
		bookList.add(new Book(101,"Devdas","Sarat Chandra Chattopadhyay"));
		bookList.add(new Book(303,"Gitanjali","Rabindranath Tagore"));
		bookList.add(new Book(404,"Chader Pahar","Bibhutibhushan Bandyopadhyay"));
		bookList.add(new Book(606,"Lord of the Rings","J.R.R Tolkien"));
		bookList.add(new Book(505,"Batul the great","Satyajit Ray"));
		
	}
	//use to return the bookList
	public static List<Book> getAllBooks(){
		return bookList;
	}

}//end of class
