package org.anudip.labAss.librarySystem;

import java.util.List;
import java.util.Scanner;

public class BookMain {

	public static void main(String[] args) {
		BookService bs = new BookService();
		List<Book> copyBookList = null;
		
	     Scanner scanner =new Scanner(System.in);
	     while(true) {
	    	 System.out.println("\n           Menu           ");
	    	 System.out.println("1.Display Book Number-wise");
	    	 System.out.println("2.Display Book Title-wise");
	    	 System.out.println("3.Display Book Author-wise");
	    	 System.out.println("4.Exit");
	    	 System.out.println("Enter choice(1-4): ");
	    	 String choice=scanner.nextLine();
	    	 switch(choice) {
	    	 case "1" :copyBookList =bs.arrangeBooksNumberWise(Library.getAllBooks());break;
	    	 case "2" :copyBookList=bs.arrangeBooksTitleWise(Library.getAllBooks());break;
	    	 case "3" :copyBookList=bs.arrangeBooksAuthorWise(Library.getAllBooks());break;
	    	 case "4" :System.exit(0);
	    	 }//end of switch
	    	 System.out.println(String.format("%-10s %-35s %-20s","BookNumber","BookTitle","Author"));
	    	 //print books
	    	 copyBookList.forEach(books->System.out.println(books));
	    
	     }//end of loop
	     
	}//end of main

}//end of class
