package org.anudip.labAss.librarySystem;

import java.util.Collections;
import java.util.List;


public class BookService {
	//arrange books in ascending order of book number
	public List<Book> arrangeBooksNumberWise(List<Book> bookList){
		Collections.sort(bookList,new NumberComparator());
		return bookList;
		
	}
	//arrange books in ascending order of book title
	 public List<Book> arrangeBooksTitleWise(List<Book> bookList) {
		 Collections.sort(bookList,new TitleComparator());
			return bookList;
		 
	 }
	 //arrange books in ascending order of author’s name
	 public List<Book> arrangeBooksAuthorWise(List<Book> bookList){
		 Collections.sort(bookList,new AuthorComparator());
			return bookList;
		 
	 }

}//end of class
