package org.anudip.labAss.companyPQR;

public class ContractEmployee extends Employee {
   private Integer contractPeriod;
   private Double contractAmount;
   private Double tax;
   private static int idGenerator=1000;
   
public ContractEmployee(String employeeId, String employeeName, String department,Integer contractPeriod, Double contractAmount) {
	super(employeeId, employeeName, department);
	this.contractPeriod = contractPeriod;
	this.contractAmount = contractAmount;
	this.tax=this.calculateTax();
	}
public Integer getContractPeriod() {
	return contractPeriod;
}

public void setContractPeriod(Integer contractPeriod) {
	this.contractPeriod = contractPeriod;
}

public Double getContractAmout() {
	return contractAmount;
}

public void setContractAmout(Double contractAmount) {
	this.contractAmount = contractAmount;
}

public Double getTax() {
	return tax;
}

public void setTax(Double tax) {
	this.tax = tax;
}

public static int getIdGenerator() {
	return idGenerator;
}

public static void setIdGenerator(int idGenerator) {
	ContractEmployee.idGenerator = idGenerator;
}

	@Override
	public double calculateTax() {
	double empTax=(contractAmount/contractPeriod)*0.10;
	return empTax;
	}

	@Override
	public String toString() {
		 return String.format("%-10s %-20s %-15s %-10s %-10s %-10s",
                 getEmployeeId(), getEmployeeName(), getDepartment(),
                 contractPeriod, contractAmount,tax);

	}
	public static int  generateId() {
		return ++idGenerator;
	}
	

}
