package org.anudip.labAss;
import java.util.Scanner;

public class CheckFibonacciNumber {
	//member function
	public static boolean isPerfectSquare(int n1) {
		int square= (int)Math.sqrt(n1);
		return (square*square==n1);
	}
	//member function
	public static boolean checkNumber(int n) {
		return isPerfectSquare(5*n*n+4)||isPerfectSquare(5*n*n-4);
	}
	
    //Main method 
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		//input a number
		System.out.println("Enter a number: ");
		int number =scanner.nextInt();
		
		//check fibonacci number or not
		if(number>=0) {
		if(checkNumber(number)) {
			System.out.println("yes");
		}else {
			System.out.println("No");
		}
	
		}
		
		scanner.close();
	}

}
