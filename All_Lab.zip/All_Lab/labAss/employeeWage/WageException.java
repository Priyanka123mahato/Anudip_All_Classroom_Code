package org.anudip.labAss.employeeWage;

public class WageException extends RuntimeException{
	static final long serialVersionUID=1l;
	public WageException(String message) {
		super(message);
	}

}
