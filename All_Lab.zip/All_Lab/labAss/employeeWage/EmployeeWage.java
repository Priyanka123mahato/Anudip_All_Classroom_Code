package org.anudip.labAss.employeeWage;

import java.text.DecimalFormat;
import java.util.Scanner;

public class EmployeeWage {
	//member method for formating the value into two decimal place values
	public static String convertTwoDecimalPlace(double value) {
		DecimalFormat decfor =new DecimalFormat("0.00");
		String decFormatValue=decfor.format(value);
		return decFormatValue;
	}

	public static void main(String[] args) {
		double totalWage=0.0;
		Scanner scanner =new Scanner(System.in);
		//Accept the number of workers
		System.out.println("Enter the number of workers: ");
		int number=Integer.parseInt(scanner.nextLine());
		//check if number is less than 5 then stop the execution of the program
		if(number<5) {
			System.out.println("Wrong workers number");
			System.exit(0);
		}
		//create wage array 
		double []wages=new double[number];
		//Accept each worker wages
		System.out.println("Enter wages of all workers-->");
		for(int i=0; i<wages.length;i++) {
			try {
			System.out.println("The wage of worker "+(i+1)+": ");
			wages[i]=Double.parseDouble(scanner.nextLine());
			if(wages[i]<100.00 || wages[i]>250.00) {
				i--;
				throw new WageException("Invalid wage");
				
			}
		}//end of try
			catch(WageException we) {
				System.out.println("WageException : "+we.getMessage());
				System.out.println("Re-enter a valid wage value");
			}//end of catch
		}//end of loop
		
		//calculate total wage and average wage
		for(int i=0; i<wages.length;i++) {
			totalWage+=wages[i];
		}
		double avgWage=(double)totalWage/wages.length;
		//formatting total wage and average wage
		String finalTotalWage=convertTwoDecimalPlace(totalWage);
		String finalAverageWage=convertTwoDecimalPlace(avgWage);
		
		//display total wage and total average
		System.out.println("The total wage is: "+finalTotalWage);
		System.out.println("Average of wage is: "+finalAverageWage);

		scanner.close();
	}//end of main method

}
