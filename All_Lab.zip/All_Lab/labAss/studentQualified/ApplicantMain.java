package org.anudip.labAss.studentQualified;
import java.util.Scanner;

public class ApplicantMain {
	//member function to calculate total
	public static int totalCalculation(Applicant applicant) {
		int subject1=applicant.getSubject1();
		int subject2=applicant.getSubject2();
		int subject3=applicant.getSubject3();
		if(subject1<50||subject2<50||subject3<50) {
			return 0;
		}
		int total=subject1+subject2+subject3;
		return total;
	}
	//member function to calculate percentage
	private static int percentageCalculation(int total) {
		int percentage=(total*100)/300;
		return percentage;
	}
	
	public static void main(String[] args) {
		Scanner scanner =new Scanner(System.in);
		//Accepting the number of applicants
		System.out.println("Enter the number of applicants: ");
		int numberOfApplicants=Integer.parseInt(scanner.nextLine());
		
		//Create Applicant type array
		Applicant [] applicantArray=new Applicant[numberOfApplicants];
		
		//accepting details of each applicants
		System.out.println("Enter details of all Applicants : ");
		for(int i=0;i<numberOfApplicants;i++) {
			String applicantsDetails =scanner.nextLine();
			String []arr=applicantsDetails.split(",");
			int subject1=Integer.parseInt(arr[1]);
			int subject2=Integer.parseInt(arr[2]);
			int subject3=Integer.parseInt(arr[3]);
			if(subject1<=0||subject1>100||subject2<=0||subject2>100||subject3<=0||subject3>100) {
				System.out.println("Error");
				continue;
			}
			//Create object of Applicant class
			Applicant applicant =new Applicant();
			//set the details of the applicant
			applicant.setName(arr[0]);
			applicant.setSubject1(subject1);
			applicant.setSubject2(subject2);
			applicant.setSubject3(subject3);
			
			//called totalCalculation()and set the value of total
		    int total=totalCalculation(applicant);
			applicant.setTotal(total);
			
			//called percentageCalculation()and set the value of percentage
			int percentage=percentageCalculation(total);
			//Store the qualifying applicant details
			if(percentage<70) {
				continue;
			}
			applicant.setPercentage(percentage);
			applicantArray[i]=applicant;
		
	   }//end for loop
		
		//Display Applicants who score minimum 70
		System.out.println("Display qualifying Students: ");
		for(Applicant ap:applicantArray) {
			 System.out.println(ap);	
		}
		scanner.close();
		
	}//end of main
	
}//end of ApplicantMain class
