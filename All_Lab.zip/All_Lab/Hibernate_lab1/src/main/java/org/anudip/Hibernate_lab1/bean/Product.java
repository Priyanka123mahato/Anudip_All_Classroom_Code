package org.anudip.Hibernate_lab1.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="product")
public class Product implements Comparable<Product>{
	@Id
	@Column(name="product_id")
	private Integer id;
	@Column(name="product_name")
    private String name;
	@Column(name="purchase_Price")
    private Double purchasedPrice;
	@Column(name="sales_price")
    private Double salesPrice;
	@Column(name="grade")
    private String grade;
	
    public Product() {
		super();
		// TODO Auto-generated constructor stub
	}
    
	public Product(Integer id, String name, Double purchasedPrice, Double salesPrice, String grade) {
		super();
		this.id = id;
		this.name = name;
		this.purchasedPrice = purchasedPrice;
		this.salesPrice = salesPrice;
		this.grade = grade;
	}

	public Integer getId() {
	     return id;
    }
    public void setId(Integer id) {
	     this.id = id;
    }
    public String getName() {
	     return name;
    }
    public void setName(String name) {
	     this.name = name;
    }
    public Double getPurchasedPrice() {
	     return purchasedPrice;
    }
    public void setPurchasedPrice(Double purchasedPrice) {
	       this.purchasedPrice = purchasedPrice;
    }
    public Double getSalesPrice() {
	       return salesPrice;
    }
    public void setSalesPrice(Double salesPrice) {
	       this.salesPrice = salesPrice;
    }
    public String getGrade() {
	        return grade;
    }
    public void setGrade(String grade) {
	        this.grade = grade;
    }
    @Override
    public String toString() {
	     String output=String.format("%-10s %-15s %-10s %-15s %-2s",id,name,purchasedPrice,salesPrice,grade);
	     return  output;
    }
    
    public int compareTo(Product second) {
		return this.getId().compareTo(second.getId());
	}

}
