package org.anudip.Hibernate_lab1.application;

import java.util.List;

import org.anudip.Hibernate_lab1.bean.Product;
import org.anudip.Hibernate_lab1.dao.DatabaseHandler;
import org.hibernate.Session;
import org.hibernate.query.Query;

public class ProductShow {

	public static void main(String[] args) throws Exception{
		DatabaseHandler dbHandler=DatabaseHandler.getDatabaseHandler();
   	    Session session=dbHandler.createSession();
   	 String queryStatement="from Product";
   	Query<Product> query=session.createQuery(queryStatement);
    List<Product> countryList=query.list();
    countryList.forEach(country->System.out.println(country));
	   	 session.close();

	}

}
