package org.anudip.Hibernate_lab1.bean;

public class PriceException extends RuntimeException{
	static final long serialVersionUID=1L;
    public PriceException(String message) {
    	super(message);
    }
}
