package org.anudip.Hibernate_lab1.bean;

public class GradeMismatchException extends RuntimeException {
	static final long serialVersionUID=1L;
    public GradeMismatchException(String message) {
    	super(message);
    }
}
