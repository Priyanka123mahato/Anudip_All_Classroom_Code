package org.anudip.Hibernate_lab1.bean;

public class EssentialCommodityException extends RuntimeException {
	static final long serialVersionUID=1L;
    public EssentialCommodityException(String message) {
    	super(message);
    }
}
