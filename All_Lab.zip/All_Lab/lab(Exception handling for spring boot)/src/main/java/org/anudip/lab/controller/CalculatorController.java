package org.anudip.lab.controller;
import org.anudip.lab.exception.OperatorException;
import org.anudip.lab.service.CalculatorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@ControllerAdvice //It handles all exceptions centrally
@RestController
public class CalculatorController {
	 @Autowired
	    private CalculatorService calService;

    @GetMapping("/calculator")
    public ModelAndView showCalculatorEntryPage() {
    	ModelAndView mv = new ModelAndView("calculatorEntry");
    	return mv;
    }

    @PostMapping("/calculator")
	public ModelAndView showCalculatorViewPage(@RequestParam("operand1") String x,@RequestParam("operand2") String y,@RequestParam("operator") String z) {
		int i=Integer.parseInt(x);
		int j=Integer.parseInt(y);
		String result=calService.performCalculation(i, j, z);
		if(result.equalsIgnoreCase("ABCD"))
			throw new OperatorException();
		ModelAndView mv=new ModelAndView("calculatorResult");
		mv.addObject("result",result);
		return mv;
	}
    @ExceptionHandler(value = ArithmeticException.class)
	   public ModelAndView handlingArithmeticException(ArithmeticException exception) {
		   String message="Divided by zero not possible";
		   ModelAndView mv=new ModelAndView("errorShow");
		   mv.addObject("errorMessage",message);
		   return mv;
	   }
    @ExceptionHandler(value = NumberFormatException.class)
	   public ModelAndView handlingNumberFormatException(NumberFormatException exception) {
		   String message="Input must be an whole number";
		   ModelAndView mv=new ModelAndView("errorShow");
		   mv.addObject("errorMessage",message);
		   return mv;
	   }
    @ExceptionHandler(value = OperatorException.class)
	   public ModelAndView handlingOperatorException(OperatorException exception) {
		   String message="Input proper mathematical operator";
		   ModelAndView mv=new ModelAndView("errorShow");
		   mv.addObject("errorMessage",message);
		   return mv;
	   }
    }
