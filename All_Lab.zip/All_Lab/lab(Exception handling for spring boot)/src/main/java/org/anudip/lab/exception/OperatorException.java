package org.anudip.lab.exception;

public class OperatorException extends RuntimeException {

}
