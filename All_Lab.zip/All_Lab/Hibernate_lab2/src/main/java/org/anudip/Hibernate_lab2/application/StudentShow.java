package org.anudip.Hibernate_lab2.application;

import java.util.Scanner;

import org.anudip.Hibernate_lab2.bean.Result;
import org.anudip.Hibernate_lab2.bean.Student;
import org.anudip.Hibernate_lab2.bean.StudentNotFoundException;
import org.anudip.Hibernate_lab2.dao.DatabaseHandler;
import org.hibernate.Session;

public class StudentShow {
   public void showStudentDetails() {
	   try {
		 //get the physical connection with the database
           Session session = DatabaseHandler.getDatabaseHandler().createSession();
           
           Scanner scanner = new Scanner(System.in);
           //accept the roll number
           System.out.print("Enter Roll Number: ");
           String rollNumber = scanner.nextLine();

           Student student = session.get(Student.class, rollNumber);
         //Check the student is present or not by the the student's roll number
           if (student == null) {
               throw new StudentNotFoundException("Student with Roll Number " + rollNumber + " not found.");
           }
          //Show the student result
           Result result = session.get(Result.class, rollNumber);
           System.out.println("Student Details:");
           System.out.println("Roll Number: " + student.getRollNumber());
           System.out.println("Student Name: " + student.getStudentName());
           System.out.println("Semester: " + student.getSemester());
           System.out.println("\nResult Details:");
           System.out.println("Half-Yearly Total: " + result.getHalfYearlyTotal());
           System.out.println("Annual Total: " + result.getAnnualTotal());
           System.out.println("Grade: " + result.getGrade());

           session.close();
       } catch (StudentNotFoundException e) {
           System.out.println(e.getMessage());
       } catch (Exception e) {
           System.out.println("Error: " + e.getMessage());
       }

   }
}
