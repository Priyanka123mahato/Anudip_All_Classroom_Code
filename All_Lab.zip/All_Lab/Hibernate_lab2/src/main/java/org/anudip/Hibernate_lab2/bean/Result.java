package org.anudip.Hibernate_lab2.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Result")
public class Result {
	@Id
	@Column(name="Roll_Number") // Map this field to the "roll_number" column in the database
	private String rollNumber;
	@Column(name="HalfYearly_Total")// Map this field to the "half_yearly_total" column in the database

    private Double halfYearlyTotal;
	@Column(name="Annual_Total")// Map this field to the "annual_total" column in the database

    private Double annualTotal;
	@Column(name="Grade")// Map this field to the "grade" column in the database

    private String grade;
	
	public Result() {
		super();
		
	}
	
	// Parameterized constructor to initialize the Result object with relevant attributes.
	public Result(String rollNumber, Double halfYearlyTotal, Double annualTotal, String grade) {
		super();
		this.rollNumber = rollNumber;
		this.halfYearlyTotal = halfYearlyTotal;
		this.annualTotal = annualTotal;
		this.grade = grade;
	}
	
	//Getter and Setter methods of the fields
	public String getRollNumber() {
		return rollNumber;
	}
	public void setRollNumber(String rollNumber) {
		this.rollNumber = rollNumber;
	}
	public Double getHalfYearlyTotal() {
		return halfYearlyTotal;
	}
	public void setHalfYearlyTotal(Double halfYearlyTotal) {
		this.halfYearlyTotal = halfYearlyTotal;
	}
	public Double getAnnualTotal() {
		return annualTotal;
	}
	public void setAnnualTotal(Double annualTotal) {
		this.annualTotal = annualTotal;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	@Override
	public String toString() {
		String result=String.format("%-5s %-20s %-20s %-5s",rollNumber,halfYearlyTotal,annualTotal,grade);
		return result;
		
	}
	
	
    
}//end of the class
