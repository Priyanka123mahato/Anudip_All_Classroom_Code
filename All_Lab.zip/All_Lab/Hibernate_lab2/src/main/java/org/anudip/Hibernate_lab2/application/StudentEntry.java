package org.anudip.Hibernate_lab2.application;

import java.util.Scanner;

import org.anudip.Hibernate_lab2.bean.Result;
import org.anudip.Hibernate_lab2.bean.Student;
import org.anudip.Hibernate_lab2.dao.DatabaseHandler;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class StudentEntry {
     public void InsertRecord(){
    	 try {
    		    //get the physical connection with the database
	            Session session = DatabaseHandler.getDatabaseHandler().createSession();
	         // Create transaction object for data insertion
	            Transaction transaction = session.beginTransaction();
                
	            Scanner scanner = new Scanner(System.in);
	            //Accept the student details
	            System.out.print("Enter Roll Number: ");
	            String rollNumber = scanner.nextLine();
                System.out.print("Enter Student Name: ");
	            String studentName = scanner.nextLine();
	            System.out.print("Enter Semester: ");
	            String semester = scanner.nextLine();
	            System.out.print("Enter Half-Yearly Total: ");
	            double halfYearlyTotal =Double.parseDouble(scanner.nextLine());
                
	            //create Result class reference to set the fields
	            Result result = new Result();
	            result.setRollNumber(rollNumber);
	            result.setHalfYearlyTotal(halfYearlyTotal);
	            //Create Student class reference
	            Student student = new Student(rollNumber, studentName, semester,result);
                
	            //save the record in database
	            session.save(student);
	          //commit the saving
	            transaction.commit();
	            session.close();
                scanner.close();
	            System.out.println("Student record added successfully.");
	        } catch (Exception e) {
	            System.out.println("Error: " + e.getMessage());
	        }

	

     }
}
