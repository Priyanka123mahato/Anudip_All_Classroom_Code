package org.anudip.Hibernate_lab2.bean;

public class ResultService {
	//Calculating the grade
	public static String gradeCalcultion(Result result) {
		double total=result.getHalfYearlyTotal()+result.getAnnualTotal();
		double percentage=(total/1000)*100;
		String studentGrade ="";
		if(percentage>=90)
			studentGrade="E";
		else if(percentage>=75)
			studentGrade="V";
		else if(percentage>=60)
			studentGrade="G";
		else if(percentage>=45)
			studentGrade="P";
		else
			studentGrade="F";
	
	return studentGrade;
	}
}//end of class

