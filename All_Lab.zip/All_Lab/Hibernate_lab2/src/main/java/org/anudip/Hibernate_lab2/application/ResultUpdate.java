package org.anudip.Hibernate_lab2.application;

import java.util.Scanner;

import org.anudip.Hibernate_lab2.bean.Result;
import org.anudip.Hibernate_lab2.bean.ResultService;
import org.anudip.Hibernate_lab2.bean.Student;
import org.anudip.Hibernate_lab2.bean.StudentNotFoundException;
import org.anudip.Hibernate_lab2.dao.DatabaseHandler;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class ResultUpdate {
	
	public void updateData() {
		 
		 try {
			//get the physical connection with the database
	            Session session = DatabaseHandler.getDatabaseHandler().createSession();
	         // Create transaction object for data insertion
	            Transaction transaction = session.beginTransaction();
                
	            Scanner scanner = new Scanner(System.in);
	            //Accept the roll number
	            System.out.print("Enter Roll Number: ");
	            String rollNumber = scanner.nextLine();
                
	            //get the existing rollNumber
	          Student student = session.get(Student.class, rollNumber);
                //Check the student is present or not by the the student's roll number
	            if (student == null) {
	                throw new StudentNotFoundException("Student with Roll Number " + rollNumber + " not found.");
	            }
	            //Update the student marks
                System.out.println("Enter the marks of English");
	            double englishMarks = Double.parseDouble(scanner.nextLine());
	            System.out.println("Enter the marks of Language");
	            double languageMarks = Double.parseDouble(scanner.nextLine());
	            System.out.println("Enter the marks of Math");
	            double mathMarks = Double.parseDouble(scanner.nextLine());
	            System.out.println("Enter the marks of Science");
	            double scienceMarks = Double.parseDouble(scanner.nextLine());
	            System.out.println("Enter the marks of Social Study");
	            double socialMarks = Double.parseDouble(scanner.nextLine());

	            double annualTotal = englishMarks + languageMarks + mathMarks + scienceMarks + socialMarks;
	            
	            Result result =student.getStudentResult();
	            result.setAnnualTotal(annualTotal);
	           
	            // Calculate grade using ResultService class
	            String grade = ResultService.gradeCalcultion(result);
                result.setGrade(grade);
              //save the record in database 
	            session.saveOrUpdate(result);
	          //commit the saving
	            transaction.commit();
	            session.close();
	            System.out.println("Student record updated successfully.");
	            
	        } catch (StudentNotFoundException e) {
	            System.out.println(e.getMessage());
	        } catch (Exception e) {
	            System.out.println("Error: " + e.getMessage());
	        }
       }

}
