package org.anudip.Hibernate_lab2.application;

import java.util.Scanner;


public class StudentMain {
	//Insert the record in the database
	public static void insertRecord () {
		  StudentEntry stuEntry = new StudentEntry();
		  stuEntry.InsertRecord();
	}
	
	//Update the exiting records
    public static void updateRecord( ) {
    	ResultUpdate updateResult = new ResultUpdate();
    	updateResult.updateData();
    	
    }
    //display the existing records
    public static void displayRecord() {
    	StudentShow studentShow = new StudentShow();
    	studentShow.showStudentDetails();
	
    }

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		while (true) {
            System.out.println("\nMenu:");
            System.out.println("1. Student Entry");
            System.out.println("2. Result Update");
            System.out.println("3. Show Student");
            System.out.println("4. Exit");
		System.out.println("Enter your Choice:");
		int choice =Integer.parseInt(scanner.nextLine());
		switch(choice) {
   	 case 1 :insertRecord();break;
   	 case 2 :updateRecord();break;
   	 case 3 :displayRecord();break;
   	 case 4 :System.exit(0);
   	 }
	
	}	
	
  }//end of main

}//end of class
