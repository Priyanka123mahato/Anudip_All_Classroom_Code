package org.anudip.Hibernate_lab2.bean;

public class StudentNotFoundException extends RuntimeException{
	static final long serialVersionUID=1L;
    public StudentNotFoundException(String message) {
    	super(message);
    }
}
