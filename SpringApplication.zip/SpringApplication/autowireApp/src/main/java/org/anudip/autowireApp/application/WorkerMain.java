package org.anudip.autowireApp.application;

import org.anudip.autowireApp.bean.Worker;
import org.anudip.autowireApp.config.WorkerConfig;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class WorkerMain {

	public static void main(String[] args) {
		ApplicationContext appContext=new AnnotationConfigApplicationContext(WorkerConfig.class);	
		Worker worker=appContext.getBean(Worker.class);
		System.out.println(worker);	
	}

}
