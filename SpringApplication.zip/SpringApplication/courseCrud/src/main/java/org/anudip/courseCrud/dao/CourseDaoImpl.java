package org.anudip.courseCrud.dao;

import java.util.List;

import org.anudip.courseCrud.bean.Course;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

@Service
@Repository
public class CourseDaoImpl implements CourseDao {
    @Autowired//it enables you to inject the object dependency implicitly
    private CourseRepository repository;
	@Override
	public void saveCourse(Course course) {//save is a own method of JpaRepsitory
		repository.save(course);           //it takes an entity of class and also save that entity and return the update one
	}

	@Override
	public List<Course> displayAllCourses() {//findAll() is a own method of JpaRepsitory
		return repository.findAll();         //it returns all the entities
		
	}

	@Override
	public Course findACourseById(Long courseId) {
		return repository.findById(courseId).get();//findById returns an entity identified using id
		
	}
	@Override
	public Long generateNewCourseId() {
		long newId=1001;
		int val=repository.getCourseCount();
		if(val>0)
			newId=newId+val;
	
		return newId;
	}

	@Override
	public void deleteCourseById(Long courseId) {
		repository.deleteById(courseId);

	}
	@Override
	public List<Long> getAllCourseIds(){
		return repository.getAllCourseIds();
	}

}
