function setFocus(){
    document.getElementById("operand1").focus();
}
function clearAll(){
    document.getElementById("calculatorForm").reset();
    setFocus();
}

function checkNumber(obj){
	let x=obj.value;
    while(isNaN(x)){
        x=prompt("Enter a whole number");
    }
    obj.value=x;
}

/* Calculation Function */
function performCalculation(){
    let x=parseInt(document.getElementById("operand1").value);
    let y=parseInt(document.getElementById("operand2").value);
    let z=document.getElementById("operator").value;
    let r=0;

    // Check if either operand is empty
    if(isNaN(x) || isNaN(y)){
        alert("Please enter values for both operands.");
        setFocus();
    } 
    else{
        switch(z){
            case "+": r=x+y; break;
            case "-": r=x-y; break;
            case "*": r=x*y; break;
            case "/": r=x/y; break;
            //default: alert("Wrong math operator");
        }
        document.getElementById("result").value=r;
    }
}

