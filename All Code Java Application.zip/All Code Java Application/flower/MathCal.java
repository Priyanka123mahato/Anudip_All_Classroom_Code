package flower;

import java.util.Scanner;

public class MathCal {

	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		 System.out.println("Enter 1st operand:");
		 int operand1=Integer.parseInt(scanner.nextLine());//operand1 is in the stack area
		 System.out.println("Enter 2nd operand:");
		 int operand2=Integer.parseInt(scanner.nextLine());//operand2 is in the stack area
		 System.out.println("Enter Math operator:");
		 String operator=scanner.nextLine();//operator is a object of String class so, it is in heap area
		 int result=0;
switch(operator) {
		 case "+" : result=operand1+operand2;break;
		 case "-" : result=operand1-operand2;break;
		 case "*" : result=operand1*operand2;break;
		 case "/" : result=operand1/operand2;break;
		 case "%" : result=operand1%operand2;break;
		 default : System.out.println("Wrong Math operator");
		  }
		 System.out.println("The result:"+result);
		 {
			 int k=8;
			 System.out.println(k);
		 }
		 //System.out.println(k); cannot access outside of the block
         
		 scanner.close();
	}

}
