package flower;
import java.util.Scanner;
public class EnployeeTax {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter the name of the employee: ");
		String name =scanner.nextLine();
		System.out.print("Enter the annual salary of the employee: ");
		double salary =Double.parseDouble(scanner.nextLine());
		double tax=0;
		 if(salary<=250000) {
			 tax=0;
			 }
		 else if( salary <=500000) {
			 tax= (salary-250000)*0.1;
		 }
         else if(salary <=1000000) {
			 tax=((salary-500000)*0.2)+30000;
		 }
         else {
        	 tax=((salary-1000000)*0.3)+50000;
			 
		 }
		 System.out.print("The name of the employee is: "+name);
		 System.out.println("and the tax is: "+tax);
		 
		 scanner.close();

	}

}
