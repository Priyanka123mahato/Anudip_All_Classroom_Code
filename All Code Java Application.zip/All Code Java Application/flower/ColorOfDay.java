package flower;
import java.util.Scanner;
public class ColorOfDay {
 public static void main(String[] args) {
	 Scanner sc = new Scanner(System.in);
	 System.out.println("Enter color name: ");
	 String colorName =sc.nextLine();
	 
	 switch(colorName) {
	 case "white" :System.out.println("Color of monday"); break;
	 case "red" :System.out.println("Color of tuesday"); break;
	 case "green" :System.out.println("Color of wednesday"); break;
	 case "yellow" :System.out.println("Color of thrusday"); break;
	 case "pink" :System.out.println("Color of friday"); break;
	 case "black" :System.out.println("Color of saturday"); break;
	 case "magenta" :System.out.println("Color of sunday"); break;
	 default: System.out.println("sorry no day is assi");
	 }
	 System.out.println("prog is over");
	 
	 // try this for short question
	 /*
	 switch(colorName) {
	 case "white" :System.out.println("Color of monday"); break;
	 case "red" :System.out.println("Color of tuesday"); break;
	 case "green" :System.out.println("Color of wednesday"); break;
	  default: System.out.println("sorry no day is assi");
	 case "yellow" :System.out.println("Color of thrusday"); break;
	 case "pink" :System.out.println("Color of friday"); break;
	 case "black" :System.out.println("Color of saturday"); break;
	 case "magenta" :System.out.println("Color of sunday"); break;
	
	 }
	 System.out.println("prog is over");
	 */
	 sc.close();
 }
}
