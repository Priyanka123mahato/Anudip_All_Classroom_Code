package flower;
import java.util.Scanner;
public class OddEven {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number: ");
		int y = sc.nextInt();
		if(y%2==0) 
			System.out.println("The number is even");
		
		else 
		System.out.println("The number is odd");
		
		sc.close();
	}
}

