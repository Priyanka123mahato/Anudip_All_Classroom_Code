package flower;

public class Rose {
	public static void show() {
		System.out.println("Hello I am Rose");
	}

}
