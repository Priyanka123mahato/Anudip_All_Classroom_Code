package flower;
import java.util.Scanner;
public class PositiveNegativeApp {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		System.out.print("Enter a number :");
		int x = sc.nextInt();
		if(x>0) {
			System.out.println("Positive Number");
		}
		else if(x<0){
			System.out.println("Negative Number");
			
		}
		else {
			System.out.println("It is 0, neither -ve nor +ve");
		}
		
		sc.close();
	}

}
