package flower;
import java.util.Scanner;
public class Perimeter {

	public static void main(String[] args) {
	Scanner sc= new Scanner(System.in);
	System.out.print("Enter the shape : ");	
	String menu=sc.nextLine();
	
	switch(menu) {
	 case "circle" : 
		 System.out.print("Enter the radius: ");
		 double r =Double.parseDouble(sc.nextLine());
		 double perimeter= 2*(22/7)*r;
		 System.out.println("Perimeter of circle : "+perimeter);
		 break;
	 case "square" : 
		 System.out.print("Enter the side: ");
		 double s =Double.parseDouble(sc.nextLine());
		 double perimeter1 = 4*s;
		 System.out.println("Perimeter of square : "+perimeter1);
		 break;
	 case "rectangle" : 
		 System.out.print("Enter the Length: ");
		 double l =Double.parseDouble(sc.nextLine());
		 System.out.print("Enter the Breadth: ");
		 double b =Double.parseDouble(sc.nextLine());
		 double perimeter2 = 2*(l+b);
		 System.out.println("Perimeter of rectangle : "+perimeter2);
		 break;
	default:System.out.println("User entered invalid shape");	 
	}
	System.out.println("Program is close.");
	
     sc.close();
	}

}
