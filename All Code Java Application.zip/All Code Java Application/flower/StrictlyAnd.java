package flower;

public class StrictlyAnd {

	public static void main(String[] args) {
		int i=10;
		int j=20;
		if(++i>5 && ++j>15) {
			System.out.println("hello");
			}
		else {
			System.out.println("hi");
		}
		System.out.println("The value of i:"+i);
		System.out.println("The value of j:"+j);
        
		int a=10;
		int b=20;
		if(++a>5 & ++b>15) {
			System.out.println("hello");
			}
		else {
			System.out.println("hi");
		}
		System.out.println("The value of a:"+a);
		System.out.println("The value of b:"+b);
	}

}
