package flower;
import java.util.Scanner;
public class MarkPercentageOfStudent {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the marks: ");
		int marks=scanner.nextInt();
		if(marks>74) {
			System.out.println("The Grade is V and the marks is "+marks);
		}
		else if(marks>59) {
			System.out.println("The Grade is G and the marks is "+marks);
		}
		else if(marks>=50) {
			System.out.println("The Grade is P and the marks is "+marks);
		}
		else {
			System.out.println("The Grade is F and the marks is "+marks);
		}
		scanner.close();
	}

}
