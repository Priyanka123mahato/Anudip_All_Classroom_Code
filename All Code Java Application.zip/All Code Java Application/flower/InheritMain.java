package flower;

public class InheritMain {

	public static void main(String[] args) {
		Derive2 d = new Derive2();
		//d.show();//we cant't access show() method because it declare as protected
		d.display();// protected data or functions can be only accessible in the same package or different package but in different package class should be sub class of that class where the protected method or variable present
		//here see fruit->Base,Derive,InheritMain(we can access)
		          //flower->Derived2(accessible) but in InheritMain(not accessible) because this is not subclass of Base class
	}

}
