package org.anudip.datetime;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
@SuppressWarnings("all")
public class DateDemo3 {
     public static void main(String[] args)throws ParseException {
		LocalDate localDate=LocalDate.now();
		//System.out.println(localDate);
		String str =localDate.toString();
		System.out.println("Before Formatting: "+str);
		
		//covert date from one format to another format
		String []arr =str.split("-");
		int year=Integer.parseInt(arr[0]);
		year=year-1900;       // for Date class start year is 1900 not 0
		int month=Integer.parseInt(arr[1]);
		month=month-1;        //for Date class for january =0 thats why we do this
		int day=Integer.parseInt(arr[2]);
		Date date =new Date(year,month,day); 
		SimpleDateFormat dateFormat=new SimpleDateFormat("dd-MM-yyyy");
		String output =dateFormat.format(date);
		System.out.println("After Formatting "+output);
	}

}
