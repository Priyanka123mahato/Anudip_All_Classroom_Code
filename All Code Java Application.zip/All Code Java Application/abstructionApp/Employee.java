package org.anudip.abstructionApp;

import java.util.Scanner;

public abstract class Employee {
private Integer employeeId;
private String employeeName;
private String deptName;
    public Employee() {
	    this.employeeId=0;
	    this.employeeName="";
	    this.deptName="";
    }
     public void getdata() {
	  Scanner scanner =new Scanner(System.in);
	  System.out.println("Enter employee id: ");
	  employeeId=Integer.parseInt(scanner.nextLine());
	  System.out.println("Emter employee name: ");
	  employeeName=scanner.nextLine();
	  System.out.println("Enter dept name: ");
	  deptName=scanner.nextLine();
	  //scanner.close();
     }
     public void showdata() {
	 System.out.println("The employee id: "+employeeId);
	 System.out.println("The employee name: "+employeeName);
	 System.out.println("The dept name: "+deptName);
	
    }
     //abstract method(which has no body)
     //abstract class can have static variable and method also
     //It can have abstract or concrete method both
     public abstract void taxCalculation();
    	 
     
}
