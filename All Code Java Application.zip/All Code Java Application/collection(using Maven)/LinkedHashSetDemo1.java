package org.anudip.mavenApllication.collection;

import java.util.LinkedHashSet;


public class LinkedHashSetDemo1 {//In case of LinkedhashSet duplicates records are not available
	                          //but depends on hashcode-value if their hashcode are different then both will be printed.
                           //Order of entry must be maintained
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedHashSet <String>mySet = new LinkedHashSet<String>();
		mySet.add("Rose");
		mySet.add("Lotus");
		mySet.add("Lily");
		mySet.add("Rose");
		mySet.add("Marigold");
		mySet.add("Sunflower");
		mySet.add("Jasmine");
		mySet.add("Cosmos");
		mySet.add("Jasmine");
		mySet.add("Delhia");
		mySet.add("Zenia");
		mySet.add("Tulip");
		mySet.add("Sunflower");
		
		
		System.out.println("Display");
		mySet.forEach(str->System.out.println(str));
		
      
	}

}
