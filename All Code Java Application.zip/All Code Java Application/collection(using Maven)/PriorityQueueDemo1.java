package org.anudip.mavenApllication.collection;

import java.util.PriorityQueue;



public class PriorityQueueDemo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PriorityQueue <String>myQueue = new PriorityQueue<String>();
		//System.out.println(myQueue.remove());
		//System.out.println(myQueue.poll());
		
		System.out.println("Original Queue:---");
		myQueue.add("Mango");
		myQueue.add("Apple");
		myQueue.add("Guava");
		myQueue.add("Pineapple");
		myQueue.add("Litchi");
		myQueue.add("Plum");
        myQueue.forEach(str->System.out.println(str));
        System.out.println("Polling:---");
        System.out.println(myQueue.poll());
        System.out.println("Afer polling the queue is:---");
        myQueue.forEach(str->System.out.println(str));
        System.out.println("Peeking--");
        System.out.println(myQueue.peek());
        System.out.println("After Peeking the queue is:---");
        myQueue.forEach(str->System.out.println(str));
	}

}
