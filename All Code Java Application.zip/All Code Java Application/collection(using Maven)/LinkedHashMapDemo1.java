package org.anudip.mavenApllication.collection;

import java.util.LinkedHashMap;
import java.util.Set;

public class LinkedHashMapDemo1 {//it is maintain the order of entry
	                       //Display Tabular format

	public static void main(String[] args) {
		        
		LinkedHashMap <Integer,String> myMap =new LinkedHashMap<>();
		myMap.put(103, "Rose");
		myMap.put(105, "Tulip");
		myMap.put(101, "Cosmos");
		myMap.put(104, "Rose");
		myMap.put(102, "Marigold");
		myMap.put(106, "Lotus");
		Set<Integer> allKeys=myMap.keySet();
		System.out.println(allKeys);
		for(Integer ig:allKeys) {
			String str=myMap.get(ig);
			System.out.println(ig+"-"+str);
		}
		}

}
