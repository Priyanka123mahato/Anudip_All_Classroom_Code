package org.anudip.mavenApllication.collection;

import java.util.HashMap;
import java.util.Set;

public class HashMapDemo2 {//run it to visulization HashMap
	                       //Display Tabular format

	public static void main(String[] args) {
		        //key   ,  value
		HashMap <Integer,String> myMap =new HashMap<>();
		myMap.put(103, "Rose");
		myMap.put(105, "Tulip");
		myMap.put(101, "Cosmos");
		myMap.put(104, "Rose");
		myMap.put(102, "Marigold");
		myMap.put(106, "Lotus");
		Set<Integer> allKeys=myMap.keySet();//arrange according to the key (means ascending)
		System.out.println(allKeys);
		for(Integer ig:allKeys) {
			String str=myMap.get(ig);
			System.out.println(ig+"-"+str);
		}
		}

}
