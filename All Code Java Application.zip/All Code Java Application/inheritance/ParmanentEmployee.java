package org.anudip.inheritance;

import java.util.Scanner;

public class ParmanentEmployee extends Employee{
     private Double monthlySalary;

	public ParmanentEmployee() {
		monthlySalary=0.0;
	}
	 public void getdata() {
		 super.getdata();
		  Scanner scanner =new Scanner(System.in);
		  System.out.println("Enter employee monthly salary: ");
		  monthlySalary=Double.parseDouble(scanner.nextLine());
		  //scanner.close();
	 }
	 public void showdata() {
		 super.showdata();
		 System.out.println("The employee monthly salary: "+monthlySalary);
	 }
	 
}
