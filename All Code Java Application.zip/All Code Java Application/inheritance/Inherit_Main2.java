package org.anudip.inheritance;

public class Inherit_Main2 {

	public static void main(String[] args) {
		Parent2 p= new Child2();
		p.show();
		
		//Solution(use super in show method of child2 class)
		Child2 ch = new Child2();
		ch.show();
		
	}

}
