package org.anudip.inheritance;

public class Car extends Vehical{
private String color;
public Car() {
	color="Red";
}
public void honk() {
	System.out.println("The color of the car is: "+color);
}
}
