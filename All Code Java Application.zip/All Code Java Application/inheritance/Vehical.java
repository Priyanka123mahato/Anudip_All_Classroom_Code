package org.anudip.inheritance;

public class Vehical {
private String brand;
private String model;
private int year;
public Vehical() {
	brand="Lomborghini";
	model="Lomborghini Reveulto";
	year=2023;
}
public void drive() {
	System.out.println("The car brand : "+brand+", model is: "+model+" and year of launching is: "+year);
}
}
