package org.anudip.inheritance;

public class InheritanceMain3 {

	public static void main(String[] args) {
		Car c=new Car();
		c.drive();
		c.honk();
		
	}

}
