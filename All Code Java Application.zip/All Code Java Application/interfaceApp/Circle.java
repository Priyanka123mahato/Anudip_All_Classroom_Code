package org.anudip.interfaceApp;

import java.text.DecimalFormat;


public class Circle implements Shape {
	 private Integer radius;
	 
	 //Decimal Formatting
     DecimalFormat decfor =new DecimalFormat("0.00");
     
     //Initialize radius of the circle
     public Circle(int radius) {
    	 this.radius=radius;
     }
     
	@Override
	public String perimeter() {
		double periCal=2*pi*radius;
		String periFormat=decfor.format(periCal);
		return periFormat;
	}

	@Override
	public String area() {
		double areaCal=pi*radius*radius;
		String areaFormat=decfor.format(areaCal);
		return areaFormat;
	}
	//print function
	public void display(String perimeter,String area) {
		System.out.println("Perimeter of the circle: "+perimeter);
		System.out.println("Area of the circle: "+area);
	}

}
