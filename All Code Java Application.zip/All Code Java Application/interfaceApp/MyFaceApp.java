package org.anudip.interfaceApp;

public class MyFaceApp {

	public static void main(String[] args) {
		MyFace mf =(stg)->{
		String str="Hello "+stg+" Welcome to Lamda expression";
		return str;
		};//end of lambda expression
		String stk="Marry";
    System.out.println(mf.showMessage(stk));
    
	}//end of main
	
}//end of class
