package org.anudip.interfaceApp;
@FunctionalInterface
public interface AdditionFace {
    public int add(int x,int y);
    
}
