package org.anudip.interfaceApp;

public interface DemoFace {
      void show();
      void display();
      int p =0;//interface data member static and final
     //interface member/functions are by default public
}
