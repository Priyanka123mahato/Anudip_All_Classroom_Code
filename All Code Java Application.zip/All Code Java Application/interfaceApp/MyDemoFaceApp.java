package org.anudip.interfaceApp;

public class MyDemoFaceApp {

	public static void main(String[] args) {
		MyDemoFaceImpl md =new MyDemoFaceImpl();
		md.show();
		md.display();
		md.dispMessage();
		
		MyDemoFace md1 =new MyDemoFaceImpl();
		md1.show();
		md1.display();
		
		MyDemoFace.putdata();
	}

}
