package org.anudip.interfaceApp;

import java.util.Scanner;

public class CircleApp {

	public static void main(String[] args) {
          Scanner scanner=new Scanner(System.in);
          //Accept the radius value of circle
          System.out.println("Enter the radius value: ");
          int r=scanner.nextInt();
          //Create object of circle of circle class
          Circle circle=new Circle(r);
          //call the perimeter and area method of circle class and set them
          String perimeter=circle.perimeter();
          String area=circle.area();
          
          //call display function of circle class
          circle.display(perimeter, area);
          scanner.close();
	}

}
