package org.anudip.interfaceApp;

public interface Shape {
	double pi=3.1416;
    public String perimeter();
    public String area();
}
