package org.anudip.interfaceApp;
//Functional interface(this interface should only have one abstract method)
@FunctionalInterface
public interface MyFace {
    public String showMessage(String stg);
    
}
