package org.anudip.mavenApplication;

import static org.junit.jupiter.api.Assertions.*;

import org.anudip.mavenApplication.app.Employee;
import org.anudip.mavenApplication.app.EmployeeSevice;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

class EmployeeServiceTest {
	private static Employee employee;
	private static EmployeeSevice empService;
	
	@BeforeAll
	public static void init() {
		empService =new EmployeeSevice();
	}
	//use to disabling a test
 @Disabled
	@Test
	void testTaxCalculation1() {
		 employee=new Employee(505,"Hilda Hill",75000.00);
		String expected ="90000.00";
		String actual =empService.taxCalculation(employee);
		System.out.println("Test1");
		assertEquals(expected,actual);
	}
	@Test
	void testTaxCalculation2() {
		 employee=new Employee(505,"Hilda Hill",125000.00);
		String expected ="375000.00";
		String actual =empService.taxCalculation(employee);
		System.out.println("Test2");
		assertEquals(expected,actual);
	}

}
