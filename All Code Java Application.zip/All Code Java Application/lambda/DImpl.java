package org.anudip.lambda;

public class DImpl implements D {

	@Override
	public void show() {
		System.out.println("Hello");
	}

	@Override
	public void disp() {
		
		System.out.println("Hi");
	}
public void putdata() {
		
		System.out.println("Hello Hi");
	}

}
