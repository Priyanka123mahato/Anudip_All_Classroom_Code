package org.anudip.lambda;

public class DMain {

	public static void main(String[] args) {
		D dd=new DImpl();
		dd.disp();
		dd.show();
		//dd.putdata(); 

	}

}
