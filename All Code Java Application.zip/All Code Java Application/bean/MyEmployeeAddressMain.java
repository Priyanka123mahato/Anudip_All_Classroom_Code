package org.anudip.bean;

import java.util.Scanner;

public class MyEmployeeAddressMain {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter number of employees entry: ");
		int no=Integer.parseInt(scanner.nextLine());
		MyEmployeeAddress [] empArr= new MyEmployeeAddress[no];//we create Employee type Array
		System.out.println("Enter Employee details in (id,name,address,dept,salary) format:---");
		for(int i=0;i<no;i++) {
			System.out.println("\nEnter details for employee " + (i + 1) + ":");
            String emp =scanner.nextLine();
			String []arr=emp.split(",");
			int id=Integer.parseInt(arr[0]);
			
			String []arr1=arr[2].split(" ");
			int pin=Integer.parseInt(arr1[2]);
			Address address= new Address(arr1[0],arr1[1],pin);
		    double salary = Double.parseDouble(arr[4]);
			
		    MyEmployeeAddress employee =new MyEmployeeAddress(id,arr[1],address,arr[3],salary);//here we should never keep any gap between them
			empArr[i]=employee;
		}
		 System.out.println(String.format("%-5s %-10s %-20s %-15s %-10s %-10s %-10s", "ID","Name","Street Address","city","pin","Dept","Salary"));



		//display 
		for(MyEmployeeAddress em:empArr) {
			System.out.println(em);
		}
		
		scanner.close();
	}

}
