package org.anudip.regex;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class RegexApp3 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter a Date: ");
		String date= scanner.nextLine();
		Pattern p1 = Pattern.compile("^(1[0-2]|0[1-9])/(3[01]|[12][0-9]|0[1-9])/[0-9]{4}$");
		Matcher m1 =p1.matcher(date);
		if(m1.matches()) {
			System.out.println("valid date");
		}else {
			System.out.println("Invalid date");
		}
		
       scanner.close();
	}

}
