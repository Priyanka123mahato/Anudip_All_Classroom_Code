package org.anudip.regex;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegexDemo3 {

	public static void main(String[] args) {
		//Pattern p1 = Pattern.compile("[a-z][a-z][a-z]s"); 
		Pattern p1 = Pattern.compile("[a-z]{3}s"); 
		String s1 ="this";
		String s2 ="bus";
		String s3 ="xs";
		String s4 = "thees";
		Matcher m1 =p1.matcher(s1);
		System.out.println(m1.matches());
		
		Matcher m2 =p1.matcher(s2);
		System.out.println(m2.matches());
		
		Matcher m3 =p1.matcher(s3);
		System.out.println(m3.matches());
		
		Matcher m4 =p1.matcher(s4);
		System.out.println(m4.matches());
		
		Pattern p2 = Pattern.compile("[a-z]{3,}s");//minimum three time maximum any time 
		 m1 =p2.matcher(s1);
		System.out.println(m1.matches());
		
		 m2 =p2.matcher(s2);
		System.out.println(m2.matches());
		
		 m3 =p2.matcher(s3);
		System.out.println(m3.matches());
		
	    m4 =p2.matcher(s4);
		System.out.println(m4.matches());


		
		
	}

}
