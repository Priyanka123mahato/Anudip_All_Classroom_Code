package org.anudip.regex;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class RegexApp2 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter a Email Id: ");
		String email= scanner.nextLine();
		Pattern p1 = Pattern.compile("^[a-zA-Z0-9+_.%-]+@gmail.com+$");
		Matcher m1 =p1.matcher(email);
		if(m1.matches()) {
			System.out.println("valid emaid id");
		}else {
			System.out.println("not valid email id");
		}
		
       scanner.close();
	}

}
