package org.anudip.io;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.Scanner;

public class FileHandlingForArrangingNumber {

	public static void main(String[] args)throws IOException {
		Scanner scanner =new Scanner(System.in);
		  int[] numbers = new int[9];
	        int oddCount = 0, evenCount = 0;

	        System.out.println("Enter 9 Single Digit Numbers:");
	        for (int i = 0; i < numbers.length; i++) {
	            numbers[i] = scanner.nextInt();
	            if (numbers[i] % 2 == 0) {
	                evenCount++;
	            } else {
	                oddCount++;
	            }
	        }

	        int[] oddNumbers = new int[oddCount];
	        int[] evenNumbers = new int[evenCount];

	        int i = 0;
	        int j = 0;

	        for (int num : numbers) {
	            if (num % 2 == 0) {
	                evenNumbers[i++] = num;
	            } else {
	                oddNumbers[j++] = num;
	            }
	        }
	        Arrays.sort(oddNumbers);
	        Arrays.sort(evenNumbers);

	        

	        writeToFile("d:/odd.txt", oddNumbers);
	        writeToFile("d:/even.txt", evenNumbers);
	        scanner.close();
	        System.out.println("Numbers written to files successfully.");

	        
	    }

	    private static void writeToFile(String filename, int[] numbers) throws IOException {
	        BufferedWriter writer = new BufferedWriter(new FileWriter(filename)); 
	            for (int num : numbers) {
	                writer.write(Integer.toString(num));
	                writer.flush();
	                writer.newLine();
	                writer.close();
	                
	            }
	    }
}





