package org.anudip.exception;

import java.util.Scanner;

public class ExcepDemo1 {

	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		try {
		System.out.println("Enter numerator:");
		int n=Integer.parseInt(scanner.nextLine());
		System.out.println("Enter divisor :");
		int d=Integer.parseInt(scanner.nextLine());
		int r=n/d;
		System.out.println("The result:"+r);
		int []arr= {10,20,30};
		System.out.println(arr[6]);
	}//end of try
		catch(ArithmeticException ae) {
			System.out.println("Divided by zero not possible");
		}//end of catch
		catch(NumberFormatException ne) {
			System.out.println("Input must be a whole number");
		}//end of catch
		catch(Exception nx) {
			System.out.println("Some error..............");
		}//end of catch
		finally {
			System.out.println("The application is over");
		}
      scanner.close();
	}
}
