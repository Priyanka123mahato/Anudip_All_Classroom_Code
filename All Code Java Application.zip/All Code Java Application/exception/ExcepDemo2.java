package org.anudip.exception;

import java.util.Scanner;

public class ExcepDemo2 {

	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		try {
		System.out.println("Enter numerator:");
		int n=Integer.parseInt(scanner.nextLine());
		System.out.println("Enter divisor :");
		int d=Integer.parseInt(scanner.nextLine());
		int r=n/d;
		if(n<d) 
			throw new NumeratorException();
		
		System.out.println("The result:"+r);
		
		
	}//end of try
		catch(ArithmeticException ae) {
			System.out.println("Divided by zero not possible");
		}//end of catch
		catch(NumberFormatException ne) {
			System.out.println("Input must be a whole number");
		}//end of catch
		catch(NumeratorException nex) {
			System.out.println("Numerator cannot be lesser than Divisor");
		}//end of catch
		
		catch(Exception nx) {
			System.out.println("Some error..............");
		}//end of catch
		finally {
			System.out.println("The application is over");
		}
      scanner.close();
	}
}
