package org.anudip.exception;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class VoterEnrollmentApplication {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
        try {
           // System.out.print("Enter the age of the person: ");
            //int age = Integer.parseInt(scanner.nextLine());
        	
        	System.out.println("Enter birth of date(dd-mm-yyyy):");
        	DateTimeFormatter dateFormat=DateTimeFormatter.ofPattern("dd-MM-yyyy");
    		System.out.println("Enter your date of birth: ");
    		String birthDate=scanner.nextLine();
    		LocalDate myBirthDate=LocalDate.parse(birthDate,dateFormat);
    		LocalDate today=LocalDate.now();
    		Period period=Period.between(myBirthDate,today);
    		int age=period.getYears();

            if (age < 1 || age > 150) {
                throw new AgeException("Wrong age. Age must be between 1 and 150.");
            } else if (age < 18) {
                throw new VoterException("Invalid age for enrollment as a voter.");
            } else {
                System.out.println("Eligible for voter enrollment.");
            }
           
        } 
        catch (AgeException ex) {
            System.out.println("AgeException: " + ex.getMessage());
        } //end of catch
        catch (VoterException ve) {
            System.out.println("VoterException: " + ve.getMessage());
        }//end of catch
       
        scanner.close();


	}

}
