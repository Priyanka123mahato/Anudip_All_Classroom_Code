package AssesmentHomework;

import java.util.Scanner;

public class SumOfPrimeNumbers {
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		//Accepting Array size
		System.out.print("Enter the size of the array : ");
		int size =scanner.nextInt();
		int []array=new int[size];
		
		//check size of array
		if(size<=0) {
			System.out.println("Invalid Input");
		}else {
			//Accepting Array elements
			System.out.println("Enter the numbers of the array : ");
			for(int i=0; i<size; i++) {
				System.out.print("array["+i+"] = ");
				 array[i] =scanner.nextInt();
				 
			 }
			int sum=0;
			for(int i=0; i<size; i++) {
				int count=0;
				
				for(int div=2; div<array[i]/2;div++) {
					if(array[i]%div==0) {
						count++;
						break;
					}
				}
				if(count==0 && array[i]!=1) {
					sum=sum+array[i];
					
				}
			}
		   if(sum==0) {
			   System.out.println("NO");
		   }else {
		   System.out.println("The sum of the prime numbers: "+sum);
		   }
		}
		scanner.close();
		
	}//end of the main
}
		



