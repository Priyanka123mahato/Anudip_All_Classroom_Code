package AssesmentHomework;

import java.util.Scanner;

public class SumOfHighestAndLowestInput {
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		//Accept the size of array from user
		System.out.print("Enter the size of the array : ");
		int size =scanner.nextInt();
		int []input=new int[size];
		
		//check size of array
		if(size<=0 || size<3) {
			System.out.println("Invalid Input");
		}else {
			System.out.println("Enter the elements of the array : ");
			for(int i=0; i<size; i++) {
				System.out.print("input["+i+"] = ");
				 input[i] =scanner.nextInt();
				 if(input[i]<=0) {
					 System.out.println("Invalid Input");
					 i--;
				  }
			 }
		
		int lowestInput=Integer.MAX_VALUE;
		int highestInput=Integer.MIN_VALUE;
		//find highestInput
		for(int i=0; i<size; i++) {
			if(highestInput<input[i]) {
				highestInput=input[i];
			}
		}
		System.out.println("The highest Input: "+highestInput);
		//find lowestInput
		for(int i=0; i<size; i++) {
			if(lowestInput>input[i]) {
				lowestInput=input[i];
			}
		}
		System.out.println("The lowest Input: "+lowestInput);
		
		//print sum of lowest and highest Input
		int sum=highestInput+lowestInput;
		System.out.println("The sum of lowest and highest Input is: "+sum);
	}
		scanner.close();
   
  }//end of main
}
		



