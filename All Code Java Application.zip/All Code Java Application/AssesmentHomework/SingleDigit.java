package AssesmentHomework;

import java.util.Scanner;

public class SingleDigit {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		//accept a number
		System.out.print("Enter a number: ");
		String number =scanner.nextLine();
		int length =number.length();
		if(length<10) {
			System.out.println("Invalid entry");
		}
		else {
			long validNumber=Long.parseLong(number);
			long sum=0;
		//add till it becomes a single digit number
		while(validNumber>9) {
			sum=0;
			while(validNumber>0) {
				sum+=validNumber%10;
				validNumber=validNumber/10;
			}
			validNumber=sum;
		}
		System.out.println(validNumber);
		}
		scanner.close();
     }//end of main
      
 }


