package AssesmentHomework;

import java.util.Scanner;

public class Main {
	//member function
	public static String extractSubString(String myString,int cutPoint,int numberOfCharacters) {
		cutPoint--;
		numberOfCharacters=cutPoint+numberOfCharacters;
		String subString=myString.substring(cutPoint,numberOfCharacters);
		return subString;
}
       public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter the String: ");
		String myString=scanner.nextLine();
		System.out.print("Enter the cutPoint: ");
		int cutPoint=Integer.parseInt(scanner.nextLine());
		System.out.print("Enter the Number of Characters: ");
		int numberOfCharacters=Integer.parseInt(scanner.nextLine());
		//print the Extracted String
		System.out.println(extractSubString(myString,cutPoint,numberOfCharacters));
		scanner.close();
	}//end of main

}
