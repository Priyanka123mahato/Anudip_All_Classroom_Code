package org.anudip.mavenApplication.generic;

public class GenericDemo<T> {
	public void swapData(T x, T y){
		System.out.println("Before Swapping value of x: "+x+" value of y:"+y);
		T z=x;
		x=y;
		y=z;
		System.out.println("After Swapping value of x: "+x+" value of y:"+y);
	}
}
//T represents any data type