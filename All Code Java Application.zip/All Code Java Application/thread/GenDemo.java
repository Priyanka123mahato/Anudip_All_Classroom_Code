package org.anudip.thread;

public class GenDemo extends ABC implements Runnable{
	private String myName;

	public GenDemo(String myName) {
		super();
		this.myName = myName;
	}
	@Override
	public void run() {
		try {
		for(int i=0;i<5;i++) {
			System.out.println("Hello, I am "+myName);
			Thread.sleep(2000);
		}//end of loop
		}//end of try
		catch(Exception e) {
			
		}//end of catch
	}

}
