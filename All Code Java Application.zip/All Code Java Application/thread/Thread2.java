package org.anudip.thread;

public class Thread2 extends Thread{
	private String word;
	private String rword;
	public Thread2(String word) {
		this.word=word;
		this.rword=null;
	}
	public String show() {
		return rword;
	}
	public void run() {
		try {
			synchronized(this)//T2 request the system that it will be only active thread ,other thread will be inactive
			{
		StringBuilder sb =new StringBuilder(word);
		sb.reverse();
		rword=sb.toString();
		notifyAll();//T2 notifies all threads that its task is complete now other threads can be active
			}
		}catch(Exception e) {
			
		}
	}
    
    
}
