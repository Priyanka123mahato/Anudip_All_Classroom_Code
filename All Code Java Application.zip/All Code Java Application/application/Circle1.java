package org.anudip.application;
//Decimal formatting program
	public class Circle1 {
		private Double radius;

		public Circle1(Double radius) {
			super();
			this.radius = radius;
		}
		
		public Double perimeterCalculation() {
			double perimeter=2*3.1416*radius;
			return perimeter;
		}
		public Double areaCalculation() {
			double area=3.1416*radius*radius;
			return area;
		}
}
