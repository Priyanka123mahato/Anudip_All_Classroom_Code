package fruit;

public class DataTypeDemo {

	public static void main(String[] args) {
		//int i=20;
		//float d=5.00;
		float p=5.00f;//because in java any number with decimal is considered as double by default
		double d=5.00;
		int b=270;
		short j=280;
		float k=(float)d;// explicit {(means with description)--->demotional-->from higher range to lower range }type casting
		double q=p;//implicit{(means without description)--->promotional-->from lower range to higher range} type casting
		System.out.println(j);
		int x=77526;
		long t=x;
		short r=(short)x;
		System.out.println("The value of r: "+r);// (interview ques)the value of r is different,it producing the same value in the form of short
		char h='d';
		System.out.println("The value of h: "+h);
		int rr=(int)h;
		System.out.println("The value of h: "+rr);
		byte bb=(byte)h;
		System.out.println("The value of h: "+bb);
		
	}

}
