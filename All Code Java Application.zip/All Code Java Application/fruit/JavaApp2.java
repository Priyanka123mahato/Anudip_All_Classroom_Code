package fruit;
import java.util.Scanner;
public class JavaApp2 {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter id: ");
		int id =sc.nextInt();
		System.out.println(" Enter name: ");
		String name =sc.nextLine();//We use veriety of datatypes so thats why we can't take name input,because this goes to the buffered area and salary input we can take 
		System.out.println("Enter salary: ");//the solution is we can use same datatypes or the solution is Solution1 class exits
		double salary =sc.nextDouble();
	
		System.out.println("Employee id: "+id);
		System.out.println("Employee name: "+name);
		System.out.println("Employee salary: "+salary);
		
		sc.close();
	}

}
