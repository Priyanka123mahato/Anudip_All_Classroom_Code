package fruit;
import java.util.Scanner;
public class Circle {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the radius: ");
		double radius=sc.nextDouble();
		double parimeter = 3.1416*radius*radius;
		double area =2*3.1416*radius;
		System.out.println("The area of the circle is: "+parimeter);
		System.out.println("The perimeter of the circle is: "+area);
        
		sc.close();
	}

}
