package fruit;
import java.util.Scanner;
public class CelsiusToFahrenheit {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the celcius value: ");
		double celcius=sc.nextDouble();
		double fahrenheit = (celcius*9/5)+32;
		System.out.println(fahrenheit);
		
      sc.close();
	}

}
