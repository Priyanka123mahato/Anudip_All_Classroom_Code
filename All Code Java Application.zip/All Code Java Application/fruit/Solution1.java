package fruit;

import java.util.Scanner;

public class Solution1 {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter id: ");
		int id =Integer.parseInt(sc.nextLine());
		
		System.out.println("Enter name: ");
		String name =sc.nextLine(); 
		
		System.out.println("Enter salary: ");
		double salary =Double.parseDouble(sc.nextLine());
	
		System.out.println("Employee id: "+id);
		System.out.println("Employee name: "+name);
		System.out.println("Employee salary: "+salary);
        
		sc.close();
	}

}
