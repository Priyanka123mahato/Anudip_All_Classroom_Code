package org.anudip.app;

import java.util.Arrays;

public class ArrayDemo2 {
	public static void main(String[]args) {
		int []arr= {60,23,57,89,25,54,11,92,73,49};
		int size=arr.length;
		System.out.println("The size of array is : "+size);
		System.out.println("Display");
		for(int x:arr) {
			System.out.println(x);
		}
		//show only the even position number of array
		
		System.out.println("The contained of arr is copy to brr: ---- ");
		int []brr= Arrays.copyOf(arr, size);
		for(int x:brr) {
			System.out.println(x);
	   }
		Arrays.sort(arr);
		System.out.println("Display after the sorting: ");
		for(int i=0; i<size; i++) {
			System.out.println(arr[i]);
		}
		System.out.println("Display after the decending order: ");
		for(int i=size-1; i>=0; i--) {
			System.out.println(arr[i]);
		}
	}

}
