package org.anudip.app;

import java.util.Scanner;

public class StringBufferDemo1 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);				;
	    System.out.println("Enter a word: ");
	    
	    
	    scanner.close();
	}

}
