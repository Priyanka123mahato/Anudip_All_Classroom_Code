package org.anudip.app;

import java.util.Scanner;

public class PalindromeCheck {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a word: ");
		String strInput = sc.nextLine();
	      StringBuffer sb = new StringBuffer(strInput);
	      sb.reverse();
	      String str = sb.toString();
	      if(strInput.equalsIgnoreCase(str))
	      {
	         System.out.println(strInput + " string is palindrome.");
	      }
	      else
	      {
	         System.out.println(strInput + " string is not palindrome.");
	      }
	      sc.close();

	}

}
