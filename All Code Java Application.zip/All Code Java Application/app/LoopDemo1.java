package org.anudip.app;

public class LoopDemo1 {

	public static void main(String[] args) {
		int counter =0;
		while(counter<5) {
			System.out.println("hello");
			counter++;
		}
		System.out.println("outside the loop");

	}

}
