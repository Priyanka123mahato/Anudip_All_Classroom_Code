package org.anudip.app;

import java.util.Arrays;
import java.util.Scanner;

public class BinarySearching {

	public static void main(String[] args) {
		int []arr = {60,80,20,100,70,10,40,90,50,30 };                        
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number to find whether is present in array & location: ");
		int n =sc.nextInt();
		Arrays.sort(arr);// in binary array should be sort in asending order first
		int result=Arrays.binarySearch(arr,n);
		if(result>=0) {
		System.out.println("value present in array");

	}else {
		System.out.println("value not present in array");
		
	}
		sc.close();

	}
}
