package org.anudip.app;

public class LoopDemo3 {

	public static void main(String[] args) {
		int counter =10;
		do {
			System.out.println("hello");
			counter++;
			if(counter>9) {
				counter=1;
			}
		}while(counter<5);
		System.out.println("outside the loop");
		

	}

}
