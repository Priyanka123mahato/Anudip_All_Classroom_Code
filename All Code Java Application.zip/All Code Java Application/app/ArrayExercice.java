package org.anudip.app;
import java.util.Scanner;
public class ArrayExercice {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		System.out.print("Enter the length of the array : ");
		int length =sc.nextInt();
		int []arr=new int[length];
		System.out.println("Enter the elements of the array : ");
		for(int i=0; i<length; i++) {
			System.out.print("arr["+i+"] = ");
			 arr[i] =sc.nextInt();
			}
		
		boolean EvenNumber=false;
		for(int x: arr) {
			if(x%2==0) {
				System.out.println(x+" is a even number");
				EvenNumber=true;
			}
			
		}
		if(!EvenNumber) {
			System.out.println("No even numbers found");
		}
	sc.close();
	}
}


