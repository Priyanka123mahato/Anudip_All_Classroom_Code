package org.anudip.app;

import java.util.Scanner;

public class SplitStringapp2 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter a name of a person: ");
		String pname =scanner.nextLine();
		String []arr =pname.split(" ");
		if(arr.length==3) {
		System.out.println("First Name: "+arr[0]);
		System.out.println("Middle Name: "+arr[1]);
		System.out.println("SurName: "+arr[2]);
		
		}else {
			System.out.println("First Name: "+arr[0]);
			System.out.println("SurName: "+arr[1]);
		
		}
		
		scanner.close();
}
}

