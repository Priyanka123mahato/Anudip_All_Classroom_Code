package org.anudip.app;
import java.util.Scanner;
public class StringDemo4 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
	System.out.println("Enter the name of the person: ");
	String pname=scanner.nextLine();
	if(pname.startsWith("a")|| pname.endsWith("i") ) {
		System.out.println("Name of a girl");
	}
	else {
		System.out.println("Name of a boy");
	}
	
	scanner.close();
	}
	

}
