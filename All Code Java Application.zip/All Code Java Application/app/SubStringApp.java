package org.anudip.app;
import java.util.Scanner;
public class SubStringApp {
	//Write a java program that will accept a string. 
	//It will accept a start number and number of chars to display. 
	//Finally display the sub string.
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the String: ");
		String str=sc.nextLine();
		System.out.println("Enter the start position: ");
		int n=Integer.parseInt(sc.nextLine());
		n--;
		System.out.println("Enter the number of chars to display: ");
		int m=Integer.parseInt(sc.nextLine());
		m=n+m;
		String sub1=str.substring(n,m);
		System.out.println(sub1);
		
		sc.close();
	}

}
