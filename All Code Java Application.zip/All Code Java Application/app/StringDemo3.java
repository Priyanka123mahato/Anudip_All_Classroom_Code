package org.anudip.app;

public  class StringDemo3 {

	public static void main(String[] args) {
		String str = "ABCDEFGH";
		System.out.println("The length of arr: "+str.length());
		for(int i=0; i<str.length(); i++) {
			char ch = str.charAt(i);
			System.out.println(ch+" ");
		}
		String stg = "     XYZPOQ    ";
		System.out.println("The length of stg: "+stg.length());
		stg=stg.trim();//strip from java 11 for knowledge 
		System.out.println("The length of stg: "+stg.length());
		
	}

}
