package org.anudip.app;
import java.util.Scanner;
public class StringDemo5 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the name of the person: ");
		String name =scanner.nextLine();
		String myName=name.toLowerCase();
		if(myName.startsWith("mr")) {
			System.out.println("Good afternoon Sir");
		}
		else if(myName.startsWith("mrs")||myName.startsWith("ms")){
			System.out.println("Good afternoon Madam");
		}else {
			System.out.println("Good afternoon");
		}
		
		System.out.println(name);
		
		scanner.close();
	}

}
