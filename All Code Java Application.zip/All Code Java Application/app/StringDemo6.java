package org.anudip.app;

public class StringDemo6 {

	public static void main(String[] args) {
		String str="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		String sub1=str.substring(5);//it display index n to end
		System.out.println(sub1);
		String sub2=str.substring(5,10);
		System.out.println(sub2);
		

	}

}
