package org.anudip.app;

public class StringDemo7 {

	public static void main(String[] args) {
		String str = "Many Ann Jones";
		String [] arr = str.split(" ");
		System.out.println(arr[0]);
		System.out.println(arr[1]);
		System.out.println(arr[2]);
		
		String str1 = "Maa,baba,bhai";
		String [] arr1 = str1.split(",");
		System.out.println(arr1[0]);
		System.out.println(arr1[1]);
		System.out.println(arr1[2]);
		
		}

}
