package org.anudip.app;

public class MultiArray1 {
	public static void main(String[]args) {
		int [][] arr= {{20,30,40,50},{25,35,45,55},{60,70,80,90}};
		int rows=arr.length;
		int cols=arr[0].length;
		for(int i=0;i<rows; i++) {
			System.out.println();
			for(int j=0; j<cols; j++) {
				System.out.print(arr[i][j]+" ");
			}
		}
	}

}
