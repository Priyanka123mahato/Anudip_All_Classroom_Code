package org.anudip.app;
import java.util.Scanner;
public class FibonacciSeries {

	public static void main(String[] args) {
		Scanner scanner =new Scanner(System.in);
		System.out.print("Enter the num : ");
		int num=scanner.nextInt();
		int fib1=0;
		int fib2=1;
		int fib3;
		int i=1;
		
		while(i<=num) {
			System.out.println(fib1+" ");
			fib3=fib1+fib2;
			fib1=fib2;
			fib2=fib3;
			i++;
		}
		
		scanner.close();

	}

}
