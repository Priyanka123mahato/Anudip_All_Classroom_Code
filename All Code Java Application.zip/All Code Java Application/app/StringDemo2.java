package org.anudip.app;

public class StringDemo2 {

	public static void main(String[] args) {
		String str = "ABCDEFGH";
		char []arr =str.toCharArray();
		System.out.println("The length of arr: "+arr.length);
		for(int i=0; i<arr.length; i++) {
			System.out.println(arr[i]);
			
		}
		System.out.println("**********");
			for(char x :arr) {
				System.out.println(x+" ");
			}
		}
	}


